/* eslint new-cap: "off", no-invalid-this: "off" */

'use strict';

const prettyJson = require('prettyjson');
const {Before, Given, When, Then} = require('cucumber');

const stepContext = {};

const prettyPrintJson = function(json) {
  const output = {
    stepContext,
    testOutput: json,
  };

  return prettyJson.render(output, {
    noColor: true,
  });
};

const callbackWithAssertion = function(callback, assertion) {
  if (assertion.success) {
    callback();
  } else {
    callback(prettyPrintJson(assertion));
  }
};

When(/^I GET (.*)$/, function(resource, callback) {
    this.apickli.get(resource, function(error, response) {
      if (error) {
        callback(new Error(error));
      }
  
      callback();
    });
  });
  
  When(/^I POST to (.*)$/, function(resource, callback) {
    this.apickli.post(resource, function(error, response) {
      if (error) {
        callback(new Error(error));
      }
  
      callback();
    });
  });
  
  When(/^I PUT (.*)$/, function(resource, callback) {
    this.apickli.put(resource, function(error, response) {
      if (error) {
        callback(new Error(error));
      }
  
      callback();
    });
  });
  
  When(/^I DELETE (.*)$/, function(resource, callback) {
    this.apickli.delete(resource, function(error, response) {
      if (error) {
        callback(new Error(error));
      }
  
      callback();
    });
  });
  
  When(/^I PATCH (.*)$/, function(resource, callback) {
    this.apickli.patch(resource, function(error, response) {
      if (error) {
        callback(new Error(error));
      }
  
      callback();
    });
  });
  
  When(/^I set bearer token$/, function(callback) {
    this.apickli.setBearerToken();
    callback();
  });
  
  When(/^I request OPTIONS for (.*)$/, function(resource, callback) {
    this.apickli.options(resource, function(error, response) {
      if (error) {
        callback(new Error(error));
      }
  
      callback();
    });
  });