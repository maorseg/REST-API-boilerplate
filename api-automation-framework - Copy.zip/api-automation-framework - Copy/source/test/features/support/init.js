/* eslint new-cap: "off", no-invalid-this: "off" */

'use strict';

const apickli = require('../../../apickli/apickli.js');
const {Before, setDefaultTimeout} = require('cucumber');

Before(function() {
  // This hook will be executed before all scenarios
  this.apickli = new apickli.Apickli('https', 'gorest.co.in/public-api/'); 
});

setDefaultTimeout(60 * 1000);
